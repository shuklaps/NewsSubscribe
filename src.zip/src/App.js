import Subscription from "./component/Subscription";

function App() {
  return <Subscription />;
}

export default App;
